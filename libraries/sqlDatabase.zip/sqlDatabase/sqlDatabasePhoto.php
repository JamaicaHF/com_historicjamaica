<?php
require_once(HJ_COMPONENT_PATH.'libraries/sqlDatabase/sqlDatabase.php');

class sqlDatabasePhoto extends sqlDatabase 
{
    //**********************************************************************************************************************************************
    function getPersonPhotoIDs($personID)
    {
        $queryResult = $this->getPersonPhotos($personID, $numRecords);
        return $this->QueryPhotos($queryResult, $numRecords);
    }
    //**********************************************************************************************************************************************
    function getPersonInfo($personID)
    { 
        $this->SelectAllStatement("person","PersonID",$personID);
        $row = $this->ExecuteQuerySingleResult();
        if ($row == null)
            return "";
        $returnString = $this->addAllPersonFieldsToResultString($personID, $row);
        return $returnString;
    }
    //**********************************************************************************************************************************************
    function getBuildingPhotoIDs($modernRoadID, $StreetNum)
    {
        $returnString = "";
        $this->SelectAllStatement("grandlist", "BuildingRoadValueID", $modernRoadID, "StreetNum", $StreetNum);
        $queryElement = $this->ExecuteQuerySingleResult();
        if ($queryElement == null)
        {
            if ($StreetNum == 0)
            {
                $this->SelectAllStatement("building", "BuildingRoadValueID", $modernRoadID, "BuildingGrandListID", $StreetNum);
     		}
            else
            {
     		    $this->SelectAllStatement("building", "BuildingRoadValueID", $modernRoadID, "StreetNum", $StreetNum);
            }
            $queryElement = $this->ExecuteQuerySingleResult();
        }
        else
        {
            $this->SelectAllStatement("building", "BuildingGrandListID", $queryElement["ID"]);
            $queryElement = $this->ExecuteQuerySingleResult();
        }
        if ($queryElement != null)
        {
            $returnString = $this->getAllPhotosForBuilding($queryElement["BuildingID"], $numPhotos);
        }
        return $returnString;
    }
    //**********************************************************************************************************************************************
    function addAllPersonFieldsToResultString($personID,$row)
    {
        require_once(HJ_COMPONENT_PATH.'libraries/classes/name.php');
        $name = new HJName;
        $name->SetNameFromDataRow($row);
        $returnString = e;
        $returnString.= $this->addField($row["PersonID"],f);
        $returnString.= $this->addField($name->BuildNameFirstNameFirst(),f);
        $returnString.= $this->addField($this->SpouseName($row),f);
        $returnString.= $this->addField($this->PersonName($row["FatherID"]),f);
        $returnString.= $this->addField($this->PersonName($row["MotherID"]),f);
        $returnString.= $this->addField($row["Source"],f); 
        $returnString.= $this->addField($row["PersonDescription"],f); 
        $birthDateInfo = HJHelper::BirthDeathDate("Born", $row["BornDate"], $row["BornPlace"], $row["BornHome"]);
        $DeathDateInfo = HJHelper::BirthDeathDate("Died", $row["DiedDate"], $row["DiedPlace"], $row["DiedHome"]);
        $BuriedDateInfo = HJHelper::BurialDate($row["DiedDate"], $row["BuriedDate"], $row["BuriedPlace"], $row["BuriedStone"]);
        $birthSourceInfo = HJHelper::BirthDeathBurialSource($row["BornSource"], $row["BornBook"], $row["BornPage"]);
        $DeathSourceInfo = HJHelper::BirthDeathBurialSource($row["DiedSource"], $row["DiedBook"], $row["DiedPage"]);
        $BuriedSourceInfo = HJHelper::BirthDeathBurialSource($row["BuriedSource"], $row["BuriedBook"], $row["BuriedPage"]);
        $returnString.= $this->addField($birthDateInfo,f);
        $returnString.= $this->addField($row["BornHome"],f);
        $returnString.= $this->addField($birthSourceInfo,f);
        $returnString.= $this->addField($DeathDateInfo,f);
        $returnString.= $this->addField($row["DiedHome"],f);
        $returnString.= $this->addField($DeathSourceInfo,f);
        $returnString.= $this->addField($BuriedDateInfo,f);
        $returnString.= $this->addField($BuriedSourceInfo,f);
        $SchoolRecords = "";
        $returnString.= $this->addField($this->GetAllSchoolRecords($personID, $SchoolRecords),a).$SchoolRecords.f;
        $buildingsLivedIn = "";
        $returnString.= $this->addField($this->GetAllBuildingLivedIn($personID, $buildingsLivedIn),a).$buildingsLivedIn.f;
        $censusYears = "";
        $returnString.= $this->addField($this->GetAllCensusRecordsForPerson($row, $censusYears),a).$censusYears.f;
		$civilWarInfo = "";
        $returnString.= $this->addField($this->GetCivilWarRecordForPerson($personID, $civilWarInfo),a).$civilWarInfo.f;
        return $returnString.e;
    }
    //**********************************************************************************************************************************************
    function getPhotoInfo($photoNum)
    {
        $hfPhotoName = HJHelper::hfPhotoName($photoNum);
        $this->SelectAllStatement("photo", "PhotoName", $hfPhotoName);
        $queryElement = $this->ExecuteQuerySingleResult();
        if ($queryElement == null)
        {
            return "";
        }
        $photoID = $this->getElement($queryElement, "PhotoID");
        $photoNotes = $this->getElement($queryElement, "PhotoNotes");
        $strArray = array();
        $strArray[] = $this->GetPhotoSource($queryElement);
        $strArray[] = $this->getElement($queryElement, "PhotoName");
        $this->GetPicturedElements($strArray, "People", $photoID, $this->getElement($queryElement, "NumPicturedPersons"));
        $this->GetPicturedElements($strArray, "Buildings", $photoID, $this->getElement($queryElement, "NumPicturedBuildings"));
        if (strlen($photoNotes) != 0) 
        {
            $strArray[] = "*Notes";
            $strArray[] = $photoNotes;
        }
        $numRecords = HJHelper::numInArray($strArray);
        $returnString = e.$numRecords.e;
        for ($i = 0; $i < $numRecords; $i++)
        {
            $returnString.= $strArray[$i].e;
        }
        return $returnString;
    }
    //**********************************************************************************************************************************************
    function GetPhotoSource($queryElement)
    {
        $source = $this->getElement($queryElement, "PhotoSource");
        if (HJHelper::emptyStr($source) || $source == "HF Collection")
        {
            return "*Jamaica HF Collection";
        }
        else
        {
            return "*".$source." Collection";
        }
    }
    //**********************************************************************************************************************************************
    function GetPicturedElements(&$strArray, $photoType, $photoID, $numPicturedElements)
    {
        if ($numPicturedElements == 0) return;
        $this->GetQueryItems($photoType, $elementTable, $orderField, $elementID_col);
        $this->SelectAllStatement($elementTable, "PhotoID", $photoID);
        $this->OrderBy($orderField);
        $queryResult = $this->ExecuteQuery();
        if ($queryResult == null) return;
        $strArray[] = "*Pictured ".$photoType;
        $i = 0;
        $countRecords = 0;
        foreach ($queryResult as $queryElement)
        {
            $orderNumber = $this->getElement($queryElement, $orderField);
            while ($i < ($orderNumber - 1))
            {
                $strArray[] = "unknown";
                $i++;
            }
            $elementID = $this->getElement($queryElement, $elementID_col);
            $personName = ($photoType == "People") ? $this->GetPersonName($elementID) : $this->GetBuildingName($elementID);
            $strArray[] = (strlen($personName) == 0) ? "unknown" : $personName;
            $countRecords++;
            $i++;
        }
        while ($i < $numPicturedElements)
        {
            $strArray[] = "unknown";
            $i++;
        }
    }
    //**********************************************************************************************************************************************
    function getAllGradesForSchoolYear($SchoolYear)
    {
	    list($schoolID, $year) = split("-", $SchoolYear);
        $this->SelectDistinctStatement("schoolrecord", "distinct Grade", "SchoolID", $schoolID, "Year", $year, "SchoolRecordType", 1);
        $this->OrderBy("Grade");
        $queryResult = $this->ExecuteQuery();
        $numRecords = count($queryResult);

        $returnString = e.$numRecords;
        foreach ($queryResult as $queryElement)
        {
            $grade = $this->getElement($queryElement, "Grade");
    		if (HJHelper::emptyStr($grade))
	    	{
		        $grade = "0";
		    }
            $returnString.=e."Grade ".$grade.d;
        }
        return $returnString;
    }
    //**********************************************************************************************************************************************
    function getSchoolRecordsForSchoolYear($SchoolYear)
    {
		$numRecords1;
		$numRecords2;
	    $returnString1 = $this->getSchoolRecordForTeachersStudents($SchoolYear, 0, $numRecords1);
	    $returnString2 = $this->getSchoolRecordForTeachersStudents($SchoolYear, 1, $numRecords2);
		$totalNumRecords = $numRecords1 + $numRecords2;
        return e.$totalNumRecords.$returnString1.$returnString2;
	}
    //**********************************************************************************************************************************************
    function getSchoolRecordForTeachersStudents($SchoolYear, $schoolRecordType, &$numRecords)
    {
	    list($schoolID, $year, $grade, $personId) = split("-", $SchoolYear);
		if (HJHelper::emptyStr($grade))
		{
		    $grade = "0";
		}
		if ($grade == "0" && $personId != 0)
		{
		    $grade = $this->GetGradeForSchoolPersonYear($schoolID, $year, $personId, $schoolRecordType);
		}
		$found = false;
		while (!$found)
		{
		    if ($this->TeacherNotPrimarySecondary($schoolRecordType, $grade))
	    	{
                $this->SelectAllStatement("schoolrecord", "SchoolID", $schoolID, "Year", $year, "SchoolRecordType", $schoolRecordType);
                $this->OrderBy("Grade");
		    }
		    else
		    {
                $this->SelectAllStatement("schoolrecord", "SchoolID", $schoolID, "Year", $year, "Grade", $grade, "SchoolRecordType", $schoolRecordType);
                $this->OrderBy("Person");
		    }
            $queryResult = $this->ExecuteQuery();
            $numRecords = count($queryResult);
			if ($numRecords != 0)
			{
			    $found = true;
			}
			else
			{
			    $grade++;
			}
		}
        foreach ($queryResult as $queryElement)
        {
            $person = $this->getElement($queryElement, "Person");
            $personId = $this->getElement($queryElement, "PersonID");
            $bornDate = $this->getElement($queryElement, "BornDate");
            $schoolRecordType = $this->getElement($queryElement, "SchoolRecordType");
            $grade = $this->getElement($queryElement, "Grade");
            $returnString.=e.$schoolID.d.$year.d.$grade.d.$schoolRecordType.d.$person.d.$personId.d;
         }
        return $returnString;
    }
    //**********************************************************************************************************************************************
	function IncrementGrade(&$grade)
	{
	    
	}
    //**********************************************************************************************************************************************
	function TeacherNotPrimarySecondary($schoolRecordType, $grade)
	{
	    if ($grade == "Grammer" || $grade == "Primary")
		{
		    return false;
		}
  		if ($schoolRecordType == 0 || $grade == "0")
		{
		    return true;
		}
		return false;
	}
    //**********************************************************************************************************************************************
	function GetGradeForSchoolPersonYear($schoolID, $year, $personId, $schoolRecordType)
	{
        $this->SelectAllStatement("schoolrecord", "SchoolID", $schoolID, "Year", $year, "PersonID", $personId, "SchoolRecordType", $schoolRecordType);
        $row = $this->ExecuteQuerySingleResult();
        if ($row == null)
        {
            $buildingName = "";
            return "";
        }
        $grade = $row["Grade"];
		return $grade;
	}
    //**********************************************************************************************************************************************
    function getAllCategoryValuesForCategory($categoryID)
    {
        if ($categoryID == 1)
        {
            return $this->Collections();
        }
        else
        {
            return $this->CategoryValues($categoryID);
        }
    }
    //**********************************************************************************************************************************************
    function CategoryValues($categoryID)
    {
        $this->SelectAllStatement("categoryvalue", "CategoryID", $categoryID);
        $queryResult = $this->ExecuteQuery();
        $numRecords = count($queryResult);
        $returnString = e.$numRecords;
        foreach ($queryResult as $queryElement)
        {
            $CateboryValueID = $this->getElement($queryElement, "CategoryValueID");
            $CateboryValueValue = $this->getElement($queryElement, "CategoryValueValue");
            $returnString.=e.$CateboryValueID.d.$CateboryValueValue.d;
        }
        return $returnString;
    }
    //**********************************************************************************************************************************************
    function Collections()
    {
        $queryResult = $this->GetDistinctCollections();
        $numRecords = 0;
        $CollectionNum = 0;
        $returnString = "";
        foreach ($queryResult as $queryElement)
        {
            $CollectionNum++;
            $PhotoSource = $this->getElement($queryElement, "PhotoSource");
            if (!HJHelper::emptyStr($PhotoSource) && !HJHelper::StrContains($PhotoSource, "??"))
            {
                $returnString.=e.$CollectionNum.d.$PhotoSource.d;
                $numRecords++;
            }
        }
        $returnString = e.$numRecords.$returnString;
        return $returnString;
    }
    //**********************************************************************************************************************************************
    function GetDistinctCollections()
    {
        $this->SelectOneNotEqualStatement("photo", "distinct PhotoSource", "PhotoSource", '');
        $this->OrderBy(PhotoSource);
        return $this->ExecuteQuery();
    }
    //**********************************************************************************************************************************************
    function getAllPhotosForCategoryValue($categoryValueID, $categoryID)
    {
        if ($categoryID == 1)
        {
            $value = $this->getPhotosFromCollection($categoryValueID - 1);
        }
        else
        {
            $this->SelectOneStatement("photocategoryvalue", "PhotoID", "CategoryValueId", $categoryValueID);
            $queryResult = $this->ExecuteQuery();
            $numRecords = count($queryResult);
            $returnString = $this->QueryPhotos($queryResult, $numRecords);
            $value = e.$numRecords.e.$returnString.e;
        }
        return $value;
    }
    //**********************************************************************************************************************************************
    function getPhotosFromCollection($indexOfCollection)
    {
        $queryResult = $this->GetDistinctCollections();
        $numRecords = count($queryResult);
        $returnString = "";
        if ($indexOfCollection < $numRecords)
        {
            $queryElement = $queryResult[$indexOfCollection];
            $returnString = $this->PhotosFromCollection($queryElement[PhotoSource], $numRecords);
        }
        return e.$numRecords.e.$returnString.e;; 
    }
    //**********************************************************************************************************************************************
    function getPersonName($personID)
    {
        if ($personID == 0)
        {
            return "unknown";
        }
        $this->SelectAllStatement("person","PersonID",$personID);
        $row = $this->ExecuteQuerySingleResult();
        if ($row == null) return "";
        require_once(HJ_COMPONENT_PATH.'libraries/classes/name.php');
        $name = new HJName;
        $name->SetNameFromDataRow($row);
        return $name->BuildNameFirstNameFirst();
    }
    //**********************************************************************************************************************************************
    function GetQueryItems($photoType, &$elementTable, &$orderField, &$elementID_col)
    {
        if ($photoType == "People")
        {
            $elementTable = "picturedperson";
            $orderField = "PicturedPersonNumber";
            $elementID_col = "PersonID";
        }
        else
        {
            $elementTable = "picturedbuilding";
            $orderField = "PicturedBuildingNumber";
            $elementID_col = "BuildingID";
        }
    }
    //**********************************************************************************************************************************************
    function getAllPhotosForCategory($categoryID)
    {
        if ($categoryID == 0)
        {
            $this->SelectAllStatement("photo");
        }
        else
        {
            //$this->SelectOneStatement("photocategoryvalue", "photo");
            $this->SelectOneStatementJoin("photocategoryvalue", "categoryvalue", "PhotoID", "CategoryValueId", "CategoryID", $categoryID);
            $arrayList = $this->ExecuteQuery();
            //$query = "select PhotoID from photocategoryvalue ".
            //         "join categoryvalue on photocategoryvalue.CategoryValueId = categoryvalue.CategoryValueId and category.CategoryID=".$categoryID;
        }
        $arrayList = $this->ExecuteQuery();
        $returnString = $this->QueryPhotos($arrayList, $numRecords);
        $value = e.$numRecords.e.$returnString.e;
        return $value;
    }
    //**********************************************************************************************************************************************
    function QueryPhotos($arrayList, &$numRecords)
    {
        if ($arrayList == null)
        {
            HJHelper::showMessage("No Photos found");
            HJHelper::backToPreviousPage();
            return "";
        }
        return $this->ReturnPhotoIds($arrayList, $numRecords);
    }
    //**********************************************************************************************************************************************
    function PhotosFromCollection($collector, &$numRecords)
    {
	    $collector = str_replace("'", "''", $collector);
        $this->SelectAllStatement("photo", "PhotoSource", $collector);
        $arrayList = $this->ExecuteQuery();
        return $this->ReturnPhotoIds($arrayList, $numRecords);
    }
    //**********************************************************************************************************************************************
    function ReturnPhotoIds($arrayList, &$numRecords)
    {
        $returnString = "";
        $numRecords = 0;
        foreach ($arrayList as $queryElement)
        {
            $photoID = $this->getElement($queryElement, "PhotoID");
            if (strlen($returnString) != 0)
            {
                $returnString.=e;
            }
            $returnString.=$this->PhotoNameNum($photoID);
            $numRecords++;
        }
        return $returnString;
    }
    //**********************************************************************************************************************************************
}
